package zoo;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;  
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;  

public class Tetris extends JFrame{
    JLabel statusbar;
    
    public Tetris() {
    	
        statusbar = new JLabel("Score : 0"); //untuk status
        add(statusbar, BorderLayout.NORTH); //letak statusbar
        Board board = new Board(this);
        add(board);
        board.start(); //memulai game

        setSize(300, 600); //ukuran window 
        setTitle("T E T R I S"); //title game
        setDefaultCloseOperation(EXIT_ON_CLOSE);
   }

   public JLabel getStatusBar() { //untuk mendapatkan status
       return statusbar;
   }
   
   private Color[][] well;
	
	// Creates a border around the well and initializes the dropping piece
	private void init() {
		well = new Color[600][300];
		for (int i = 0; i < 600; i++) {
			for (int j = 0; j < 300; j++) {
					well[i][j] = Color.GRAY;
			}
		}
	}

    public static void main(String[] args) {
        Tetris game = new Tetris();
        game.setLocationRelativeTo(null);
        game.setVisible(true);

    } 
}